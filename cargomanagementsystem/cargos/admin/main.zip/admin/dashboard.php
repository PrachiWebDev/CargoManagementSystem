<?php
session_start();

// Check if user is logged in and is admin
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== "admin"){
    header("location: ../index.php");
    exit;
}

require_once "../config/database.php";

// Get total counts
$total_customers = 0;
$total_shipments = 0;
$total_vehicles = 0;
$total_locations = 0;

// Get total customers
$sql = "SELECT COUNT(*) as total FROM customers";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)){
    $total_customers = $row['total'];
}

// Get total shipments
$sql = "SELECT COUNT(*) as total FROM shipments";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)){
    $total_shipments = $row['total'];
}

// Get total vehicles
$sql = "SELECT COUNT(*) as total FROM vehicles";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)){
    $total_vehicles = $row['total'];
}

// Get total locations
$sql = "SELECT COUNT(*) as total FROM locations";
$result = mysqli_query($conn, $sql);
if($row = mysqli_fetch_assoc($result)){
    $total_locations = $row['total'];
}

// Get recent shipments
$recent_shipments = array();
$sql = "SELECT s.*, c.full_name as customer_name, l1.name as pickup_location, l2.name as delivery_location 
        FROM shipments s 
        LEFT JOIN customers c ON s.customer_id = c.id 
        LEFT JOIN locations l1 ON s.pickup_location_id = l1.id 
        LEFT JOIN locations l2 ON s.delivery_location_id = l2.id 
        ORDER BY s.created_at DESC LIMIT 5";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result)){
    $recent_shipments[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Cargo Management System</title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #212529;
            color: #fff;
        }
        .sidebar .nav-link {
            color: #fff;
            padding: 10px 20px;
        }
        .sidebar .nav-link:hover {
            background-color: #0d6efd;
        }
        .sidebar .nav-link.active {
            background-color: #0d6efd;
        }
        .main-content {
            padding: 20px;
        }
        .stat-card {
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar">
                <div class="p-3">
                    <h4 class="text-center">Cargo Management</h4>
                    <hr>
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" href="dashboard.php">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="customers.php">
                                <i class="fas fa-users me-2"></i> Customers
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="shipments.php">
                                <i class="fas fa-shipping-fast me-2"></i> Shipments
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="vehicles.php">
                                <i class="fas fa-truck me-2"></i> Vehicles
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="locations.php">
                                <i class="fas fa-map-marker-alt me-2"></i> Locations
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-bar me-2"></i> Reports
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../logout.php">
                                <i class="fas fa-sign-out-alt me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2>Dashboard</h2>
                    <div>
                        <span class="me-3">Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?></span>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Customers</h5>
                                <h2 class="card-text"><?php echo $total_customers; ?></h2>
                                <i class="fas fa-users fa-2x position-absolute top-50 end-0 me-3 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Shipments</h5>
                                <h2 class="card-text"><?php echo $total_shipments; ?></h2>
                                <i class="fas fa-shipping-fast fa-2x position-absolute top-50 end-0 me-3 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-warning text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Vehicles</h5>
                                <h2 class="card-text"><?php echo $total_vehicles; ?></h2>
                                <i class="fas fa-truck fa-2x position-absolute top-50 end-0 me-3 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body">
                                <h5 class="card-title">Total Locations</h5>
                                <h2 class="card-text"><?php echo $total_locations; ?></h2>
                                <i class="fas fa-map-marker-alt fa-2x position-absolute top-50 end-0 me-3 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Shipments -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Recent Shipments</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Tracking #</th>
                                        <th>Customer</th>
                                        <th>Pickup</th>
                                        <th>Delivery</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($recent_shipments as $shipment): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($shipment['tracking_number']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['customer_name']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['pickup_location']); ?></td>
                                        <td><?php echo htmlspecialchars($shipment['delivery_location']); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $shipment['status'] == 'delivered' ? 'success' : 
                                                    ($shipment['status'] == 'in_transit' ? 'primary' : 
                                                    ($shipment['status'] == 'cancelled' ? 'danger' : 'warning')); 
                                            ?>">
                                                <?php echo ucfirst($shipment['status']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo date('M d, Y', strtotime($shipment['created_at'])); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3 JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 